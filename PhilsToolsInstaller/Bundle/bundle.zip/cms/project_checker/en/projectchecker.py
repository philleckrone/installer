import ScriptureObjects
import os
import subprocess

selectedProject = ScriptureObjects.ScriptureText(Project)
projectDir = selectedProject.directory

exePath = os.path.abspath(os.path.join(projectDir, "..", "cms", "ProjectChecker.exe"))

if not os.path.exists(exePath):
    print("ProjectChecker.exe not found at: " + exePath)
else:
    subprocess.Popen([exePath, projectDir])
